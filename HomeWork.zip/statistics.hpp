#include <vector>
#pragma once

int RanStatistics(std::vector<double> &results);