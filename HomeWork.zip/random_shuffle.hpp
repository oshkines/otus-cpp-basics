#include <vector>
#pragma once
void RandomVector(std::vector<int> &vec);